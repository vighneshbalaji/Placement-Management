--
-- Database: `placement`
--

-- --------------------------------------------------------

--
-- Table structure for table `company`
--

CREATE TABLE `company` (
  `companyid` int(11) NOT NULL,
  `companyname` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `company`
--

INSERT INTO `company` (`companyid`, `companyname`) VALUES
(1, 'Amazon'),
(2, 'Apple'),
(3, 'Capgemini'),
(4, 'Cognizant'),
(5, 'Dell'),
(6, 'HCL'),
(7, 'HP'),
(8, 'Infosys'),
(9, 'Microsoft'),
(10, 'TCS'),
(11, 'Wipro'),
(12, 'Verizon');

-- --------------------------------------------------------

--
-- Table structure for table `departmentinfo`
--

CREATE TABLE `departmentinfo` (
  `departmentid` varchar(5) NOT NULL,
  `instituteid` varchar(11) NOT NULL,
  `departmentname` varchar(5) NOT NULL,
  `years` int(11) NOT NULL,
  `sections` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `departmentinfo`
--

INSERT INTO `departmentinfo` (`departmentid`, `instituteid`, `departmentname`, `years`, `sections`) VALUES
('d1', 'in1', 'cs', 3, 3),
('d1', 'in3', 'cs', 3, 2),
('d3', 'in1', 'it', 3, 2),
('d4', 'in1', 'ct', 3, 2),
('d5', 'in1', 'ss', 5, 2),
('d6', 'in3', 'it', 3, 2);

-- --------------------------------------------------------

--
-- Table structure for table `institute`
--

CREATE TABLE `institute` (
  `instituteid` varchar(4) NOT NULL,
  `institutename` varchar(20) NOT NULL,
  `email` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `institute`
--

INSERT INTO `institute` (`instituteid`, `institutename`, `email`) VALUES
('in1', 'kgcas', 'kgcas@gmail.com'),
('in3', 'kct', 'kct@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `placementdetails`
--

CREATE TABLE `placementdetails` (
  `placementid` int(11) NOT NULL,
  `instituteid` varchar(4) DEFAULT NULL,
  `companyid` int(11) NOT NULL,
  `SSLC` int(11) NOT NULL,
  `HSC` int(11) NOT NULL,
  `UG` varchar(20) NOT NULL,
  `arrear` varchar(1) NOT NULL,
  `jobinfo` varchar(40) NOT NULL,
  `date` date NOT NULL,
  `recruited` int(11) DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `placementdetails`
--

INSERT INTO `placementdetails` (`placementid`, `instituteid`, `companyid`, `SSLC`, `HSC`, `UG`, `arrear`, `jobinfo`, `date`, `recruited`, `status`) VALUES
(1, 'in1', 3, 60, 60, '60', 'n', 'Web Designer', '2017-10-30', NULL, 0),
(2, 'in1', 1, 60, 60, '60', 'y', 'Customer Care', '2017-10-28', NULL, 0),
(3, 'in1', 10, 60, 60, '60', 'n', 'Web Designer', '2017-11-04', NULL, 0),
(4, 'in3', 11, 70, 70, '70', 'n', 'Web Designer', '2017-11-04', NULL, 0),
(5, 'in1', 10, 60, 60, '60', 'y', 'Software Engineer', '2017-11-30', NULL, 0),
(6, 'in1', 4, 50, 50, '50', 'n', 'Software Designer', '2017-12-01', NULL, 0),
(7, 'in1', 1, 60, 60, '60', 'y', 'Tester', '2017-12-02', NULL, 0),
(8, 'in1', 7, 40, 40, '40', 'y', 'Analyst', '2017-12-08', NULL, 0),
(10, 'in1', 8, 60, 60, '60', 'y', 'Web Designer', '2017-12-21', NULL, 0),
(11, 'in1', 2, 80, 80, '80', 'n', 'Testing', '2017-12-23', NULL, 0),
(12, 'in1', 9, 90, 90, '90', 'n', 'Web Designer', '2017-12-23', NULL, 0),
(13, 'in1', 8, 90, 90, '90', 'n', 'Web Designer', '2017-12-23', NULL, 0),
(14, 'in1', 6, 60, 60, '60', 'y', 'Web Designer', '2017-12-28', NULL, 1),
(17, 'in1', 12, 60, 60, '60', 'n', 'Web Designer', '2017-12-30', NULL, 1),
(23, 'in1', 3, 70, 70, '70', 'y', 'Web Designer', '2017-12-30', NULL, 1);

-- --------------------------------------------------------

--
-- Table structure for table `placementresult`
--

CREATE TABLE `placementresult` (
  `placementid` int(11) NOT NULL,
  `studentid` varchar(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `placementresult`
--

INSERT INTO `placementresult` (`placementid`, `studentid`) VALUES
(8, 's115csa1'),
(8, 's115csa2'),
(8, 's115csa3'),
(8, 's115csb1'),
(8, 's115csb2');

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `id` int(11) NOT NULL,
  `studentid` varchar(11) NOT NULL,
  `studentname` varchar(30) NOT NULL,
  `SSLC` int(11) DEFAULT NULL,
  `HSC` int(11) DEFAULT NULL,
  `UG` int(11) DEFAULT NULL,
  `arrear` varchar(1) DEFAULT NULL,
  `address` varchar(200) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `mobileno` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`id`, `studentid`, `studentname`, `SSLC`, `HSC`, `UG`, `arrear`, `address`, `email`, `mobileno`) VALUES
(30, 's115csa1', 'Sathish', 60, 60, 60, 'n', 'Muthanam Kullam', 'sathishsmile@gmail.com', '7708477566'),
(31, 's115csa2', 'Raj Kumar', 70, 70, 70, 'n', 'Lolly Road', 'rajkumar@gmail.com', '9876543210'),
(51, 's115csa3', 'Gokul', 60, 65, 72, 'n', 'ooty', 'gokullukog7474@gmail.com', '9685749685'),
(32, 's115csb1', 'Vighneshbalaji M', 88, 80, 84, 'n', 'sithi vinayagar kovil street', 'vighneshbalaji.m@gmail.com', '9488800942'),
(33, 's115csb2', 's115csb2', 40, 50, 50, 'n', NULL, 's115csb2@gmail.com', NULL),
(34, 's115csb3', 's115csb3', 60, 50, 40, 'y', NULL, 's115csb3@gmail.com', NULL),
(35, 's115csb4', 's115csb4', 70, 70, 80, 'y', NULL, 's115csb4@gmail.com', NULL),
(36, 's115csb5', 's115csb5', 50, 40, 20, 'y', NULL, 's115csb5@gmail.com', NULL),
(42, 's115cta1', 's115cta1', 40, 55, 60, 'n', NULL, 's115cta1@gmail.com', NULL),
(43, 's115cta2', 's115cta2', 50, 59, 50, 'n', NULL, 's115cta2@gmail.com', NULL),
(44, 's115cta3', 's115cta3', 20, 30, 30, 'y', NULL, 's115cta3@gmail.com', NULL),
(45, 's115cta4', 's115cta4', 66, 70, 80, 'n', NULL, 's115cta4@gmail.com', NULL),
(37, 's115ita1', 's115ita1', 70, 70, 70, 'n', NULL, 's115ita1@gmail.com', NULL),
(38, 's115ita2', 's115ita2', 50, 50, 55, 'n', NULL, 's115ita2@gmail.com', NULL),
(39, 's115ita3', 's115ita3', 65, 90, 55, 'y', NULL, 's115ita3@gmail.com', NULL),
(40, 's115ita4', 's115ita4', 70, 77, 50, 'n', NULL, 's115ita4@gmail.com', NULL),
(41, 's115ita5', 's115ita5', 40, 45, 42, 'y', NULL, 's115ita5@gmail.com', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `studentplacementregister`
--

CREATE TABLE `studentplacementregister` (
  `placementid` int(11) NOT NULL,
  `studentid` varchar(11) NOT NULL,
  `resume` varchar(200) NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `studentplacementregister`
--

INSERT INTO `studentplacementregister` (`placementid`, `studentid`, `resume`, `date`) VALUES
(5, 's115csa1', 'Vighneshbalaji Mohan RESUME Modified AUG-2017 For Online.pdf', '2017-11-28'),
(10, 's115csb1', 'Vighneshbalaji Mohan RESUME old.pdf', '2017-12-18'),
(11, 's115csb1', 'Vighneshbalaji Mohan RESUME old.pdf', '2017-12-18');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `userid` varchar(11) NOT NULL,
  `usertype` varchar(2) NOT NULL,
  `username` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `userid`, `usertype`, `username`, `password`) VALUES
(1, 'ad1', 'ad', 'vighneshbalaji', 'vicky007'),
(2, 'in1', 'in', 'kgcas', 'kgcas'),
(3, 'in3', 'in', 'kct', 'kct@123'),
(47, 's115csa1', 'st', 'Sathish', 's115csa1'),
(48, 's115csa2', 'st', 'Raj Kumar', 's115csa2'),
(68, 's115csa3', 'st', 's115csa3', 's115csa3'),
(69, 's115csa4', 'st', 's115csa4', 's115csa4'),
(70, 's115csa5', 'st', 's115csa5', 's115csa5'),
(49, 's115csb1', 'st', 'Vighneshbalaji M', 's115csb1'),
(50, 's115csb2', 'st', 's115csb2', 's115csb2'),
(51, 's115csb3', 'st', 's115csb3', 's115csb3'),
(52, 's115csb4', 'st', 's115csb4', 's115csb4'),
(53, 's115csb5', 'st', 's115csb5', 's115csb5'),
(71, 's115csb6', 'st', 's115csb6', 's115csb6'),
(72, 's115csb7', 'st', 's115csb7', 's115csb7'),
(59, 's115cta1', 'st', 's115cta1', 's115cta1'),
(60, 's115cta2', 'st', 's115cta2', 's115cta2'),
(61, 's115cta3', 'st', 's115cta3', 's115cta3'),
(62, 's115cta4', 'st', 's115cta4', 's115cta4'),
(54, 's115ita1', 'st', 's115ita1', 's115ita1'),
(55, 's115ita2', 'st', 's115ita2', 's115ita2'),
(56, 's115ita3', 'st', 's115ita3', 's115ita3'),
(57, 's115ita4', 'st', 's115ita4', 's115ita4'),
(58, 's115ita5', 'st', 's115ita5', 's115ita5'),
(63, 's315csa1', 'st', 's315csa1', 's315csa1'),
(64, 's315csa2', 'st', 's315csa2', 's315csa2'),
(65, 's315csa3', 'st', 's315csa3', 's315csa3'),
(66, 's315csa4', 'st', 's315csa4', 's315csa4'),
(67, 's315csa5', 'st', 's315csa5', 's315csa5');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `company`
--
ALTER TABLE `company`
  ADD PRIMARY KEY (`companyid`),
  ADD KEY `companyid` (`companyid`);

--
-- Indexes for table `departmentinfo`
--
ALTER TABLE `departmentinfo`
  ADD PRIMARY KEY (`departmentid`,`instituteid`),
  ADD KEY `departmentid` (`departmentid`),
  ADD KEY `instituteid` (`instituteid`);

--
-- Indexes for table `institute`
--
ALTER TABLE `institute`
  ADD PRIMARY KEY (`instituteid`),
  ADD UNIQUE KEY `email` (`email`),
  ADD KEY `instituteid` (`instituteid`);

--
-- Indexes for table `placementdetails`
--
ALTER TABLE `placementdetails`
  ADD PRIMARY KEY (`placementid`),
  ADD KEY `placementid` (`placementid`),
  ADD KEY `instituteid` (`instituteid`),
  ADD KEY `companyid` (`companyid`);

--
-- Indexes for table `placementresult`
--
ALTER TABLE `placementresult`
  ADD KEY `studentid_fk` (`studentid`),
  ADD KEY `placementid_fk` (`placementid`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`studentid`),
  ADD UNIQUE KEY `id` (`id`),
  ADD UNIQUE KEY `mobileno` (`mobileno`),
  ADD UNIQUE KEY `mail` (`email`),
  ADD KEY `studentid` (`studentid`),
  ADD KEY `studentid_2` (`studentid`),
  ADD KEY `studentid_3` (`studentid`);

--
-- Indexes for table `studentplacementregister`
--
ALTER TABLE `studentplacementregister`
  ADD KEY `placementid` (`placementid`),
  ADD KEY `studentid` (`studentid`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`userid`),
  ADD UNIQUE KEY `id` (`id`),
  ADD KEY `userid` (`userid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `placementdetails`
--
ALTER TABLE `placementdetails`
  MODIFY `placementid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;
--
-- AUTO_INCREMENT for table `student`
--
ALTER TABLE `student`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=56;
--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=73;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `departmentinfo`
--
ALTER TABLE `departmentinfo`
  ADD CONSTRAINT `instituteid_fk` FOREIGN KEY (`instituteid`) REFERENCES `institute` (`instituteId`);

--
-- Constraints for table `placementdetails`
--
ALTER TABLE `placementdetails`
  ADD CONSTRAINT `placementdetails_ibfk_1` FOREIGN KEY (`companyid`) REFERENCES `company` (`companyId`),
  ADD CONSTRAINT `placementdetails_ibfk_2` FOREIGN KEY (`instituteid`) REFERENCES `institute` (`instituteId`);

--
-- Constraints for table `placementresult`
--
ALTER TABLE `placementresult`
  ADD CONSTRAINT `placementid_fk` FOREIGN KEY (`placementid`) REFERENCES `placementdetails` (`placementid`),
  ADD CONSTRAINT `studentid_fk` FOREIGN KEY (`studentid`) REFERENCES `student` (`studentid`);

--
-- Constraints for table `studentplacementregister`
--
ALTER TABLE `studentplacementregister`
  ADD CONSTRAINT `stuplareg_placementid_fk` FOREIGN KEY (`placementid`) REFERENCES `placementdetails` (`placementid`),
  ADD CONSTRAINT `stuplareg_studentid_fk` FOREIGN KEY (`studentid`) REFERENCES `student` (`studentid`);

DELIMITER $$
--
-- Events
--
CREATE DEFINER=`root`@`localhost` EVENT `placementupt` ON SCHEDULE EVERY 1 MINUTE STARTS '2017-11-04 16:43:33' ON COMPLETION NOT PRESERVE ENABLE DO UPDATE placementdetails set status = 0
where date <= now()$$

DELIMITER ;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
